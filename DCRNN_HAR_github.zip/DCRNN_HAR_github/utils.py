import logging
import numpy as np
import os
import pickle
import scipy.sparse as sp
import sys
import tensorflow as tf
import pandas as pd
from scipy.sparse import linalg
from torch.utils.data import TensorDataset, DataLoader
import torch
from statsmodels.tsa.api import VAR
from scipy import stats



class DataLoader(object):
    def __init__(self, xs, ys, EAs, Exs, Eys, As, batch_size, shuffle=False):
        """
        Initializes the DataLoader object.
        
        :param xs: Numpy array of all input features.
        :param ys: Numpy array of all target values.
        :param batch_size: The number of samples per batch.
        :param shuffle: Whether to shuffle the data before creating batches.
        """
        self.batch_size = batch_size
        self.current_ind = 0
        self.size = len(xs) - (len(xs) % batch_size)
        
        if shuffle:
            permutation = np.random.permutation(self.size)
            xs, ys, EAs, Exs, Eys, As = xs[permutation], ys[permutation], EAs[permutation], Exs[permutation], Eys[permutation], As[permutation]
        
        self.xs = xs[:self.size]
        self.ys = ys[:self.size]
        self.EAs = EAs[:self.size]
        self.Exs = Exs[:self.size]
        self.Eys = Eys[:self.size]
        self.As = As[:self.size]
        self.num_batch = int(self.size // self.batch_size)

    def get_iterator(self):
        """
        Returns an iterator to go over the batches.
        """
        self.current_ind = 0

        def _wrapper():
            while self.current_ind < self.num_batch:
                start_ind = self.batch_size * self.current_ind
                end_ind = start_ind + self.batch_size
                x_i = self.xs[start_ind:end_ind, ...]
                y_i = self.ys[start_ind:end_ind, ...]
                EAs_i = self.EAs[start_ind:end_ind, ...]
                Exs_i = self.Exs[start_ind:end_ind, ...]
                Eys_i = self.Eys[start_ind:end_ind, ...]
                A_i = self.As[start_ind:end_ind, ...]
                yield (x_i, y_i, EAs_i, Exs_i, Eys_i, A_i)
                self.current_ind += 1

        return _wrapper()

class StandardScaler:
    """
    Standardizes the input by removing the mean and scaling to unit variance.
    Uses NumPy for fitting and transforming, and PyTorch for inverse transforming.
    """
    def __init__(self, mean=None, std=None):
        self.mean = np.array(mean, dtype=np.float32) if mean is not None else None
        self.std = np.array(std, dtype=np.float32) if std is not None else None

    def transform(self, data):
        """
        Transform the data using the mean and std obtained from fitting.
        Assumes data is a NumPy array.
        """
        return (data - self.mean) / self.std

    def inverse_transform(self, data):
        """
        Inverse the transformation applied to PyTorch tensors.
        Assumes data is a PyTorch tensor.
        """
        mean = torch.as_tensor(self.mean, dtype=data.dtype, device=data.device)
        std = torch.as_tensor(self.std, dtype=data.dtype, device=data.device)
        return (data * std) + mean


def add_simple_summary(writer, names, values, global_step):
    """
    Writes summary for a list of scalars.
    :param writer:
    :param names:
    :param values:
    :param global_step:
    :return:
    """
    for name, value in zip(names, values):
        summary = tf.Summary()
        summary_value = summary.value.add()
        summary_value.simple_value = value
        summary_value.tag = name
        writer.add_summary(summary, global_step)


def calculate_normalized_laplacian(adj):
    """
    L = D^-1/2 (D-A) D^-1/2 = I - D^-1/2 A D^-1/2
    D = diag(A 1)
    :param adj: Adjacency matrix
    :return: Normalized Laplacian matrix
    """
    d = np.array(adj.sum(axis=1)).flatten().astype(float)
    d_inv_sqrt = np.power(d, -0.5)
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = np.diag(d_inv_sqrt)
    normalized_laplacian = np.eye(adj.shape[0]) - d_mat_inv_sqrt @ adj @ d_mat_inv_sqrt
    return normalized_laplacian

def calculate_random_walk_matrix(adj):
    """
    Calculate the random walk matrix.
    :param adj: Adjacency matrix
    :return: Random walk matrix
    """
    d = np.array(adj.sum(axis=1)).flatten().astype(float)
    d_inv = np.power(d, -1)
    d_inv[np.isinf(d_inv)] = 0.
    d_mat_inv = np.diag(d_inv)
    random_walk_mx = d_mat_inv @ adj
    return random_walk_mx

def calculate_reverse_random_walk_matrix(adj):
    """
    Calculate the reverse random walk matrix.
    :param adj: Adjacency matrix
    :return: Reverse random walk matrix
    """
    return calculate_random_walk_matrix(adj.T)

def calculate_scaled_laplacian(adj, lambda_max=2, undirected=True):
    """
    Calculate the scaled Laplacian matrix.
    :param adj: Adjacency matrix
    :param lambda_max: Scaling factor
    :param undirected: If True, treat the graph as undirected
    :return: Scaled Laplacian matrix
    """
    if undirected:
        adj = np.maximum(adj, adj.T)
    L = calculate_normalized_laplacian(adj)
    if lambda_max is None:
        lambda_max = np.linalg.eigvalsh(L).max()
    M = L.shape[0]
    I = np.eye(M)
    L = (2 / lambda_max * L) - I
    return L.astype(np.float32)


def config_logging(log_dir, log_filename='info.log', level=logging.INFO):
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    try:
        os.makedirs(log_dir)
    except OSError:
        pass
    file_handler = logging.FileHandler(os.path.join(log_dir, log_filename))
    file_handler.setFormatter(formatter)
    file_handler.setLevel(level=level)
    console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(console_formatter)
    console_handler.setLevel(level=level)
    logging.basicConfig(handlers=[file_handler, console_handler], level=level)


def get_logger(log_dir, name, log_filename='info.log', level=logging.INFO):
    logger = logging.getLogger(name)
    logger.setLevel(level)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler = logging.FileHandler(os.path.join(log_dir, log_filename))
    file_handler.setFormatter(formatter)
    console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(console_formatter)
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    logger.info('Log directory: %s', log_dir)
    return logger


def get_total_trainable_parameter_size():
    """
    Calculates the total number of trainable parameters in the current graph.
    :return:
    """
    total_parameters = 0
    for variable in tf.trainable_variables():
        total_parameters += np.product([x.value for x in variable.get_shape()])
    return total_parameters

def graph_mask_generation(data):
    filter_matrix = np.ones((data.shape[0], data.shape[1], data.shape[1]))
    zero_indices = np.where(data == 0)
    for date_idx, market_idx in zip(*zero_indices):
        filter_matrix[date_idx, market_idx, :] = 0
    return filter_matrix 

def data_mask_generation(data):
    filter_matrix = np.ones((data.shape[0], data.shape[1]))
    zero_indices = np.where(data == 0)
    for date_idx, market_idx in zip(*zero_indices):
        filter_matrix[date_idx, market_idx] = 0
        filter_matrix[date_idx, market_idx] = 0
    return filter_matrix 


def compute_spillover_index(data, horizon, lag, scarcity_prop, standardized=True):
    """
    Computes the spillover index using the generalized FEVD (GFEVD).
    
    Parameters:
      data (np.array): The input data.
      horizon (int): The forecast horizon (number of steps ahead).
      lag (int): The lag order for the VAR model.
      scarcity_prop (float): The quantile for sparsity thresholding.
      standardized (bool): Whether to standardize rows to sum to 1.
    
    Returns:
      np.array: A (K x K) matrix (after sparsity thresholding and optional standardization),
                where each entry (i, j) represents the spillover from variable i to variable j.
    """
    import numpy as np
    import pandas as pd
    from statsmodels.tsa.vector_ar.var_model import VAR

    data_cleaned = data[~np.any(data == 0, axis=1)]
    
    model = VAR(data_cleaned)
    results = model.fit(maxlags=lag)
    
    A = results.ma_rep(maxn=horizon)
    
    Sigma = results.sigma_u 
    K = Sigma.shape[0]
    
    num = np.zeros((K, K))  
    den = np.zeros(K)      
    
    for h in range(horizon):
        Phi_h = A[h]
        num += (Phi_h @ Sigma) ** 2 
        den += np.diag(Phi_h @ Sigma @ Phi_h.T)
    num = num / np.diag(Sigma)[np.newaxis, :]
    gfevd = num / den[:, np.newaxis]
    
    if standardized:
        gfevd = gfevd / gfevd.sum(axis=1, keepdims=True)
    spillover_matrix = gfevd.T
    spillover_matrix *= 100 
    
    results_df = pd.DataFrame(spillover_matrix, columns=results.names, index=results.names)
    
    vsp_df_sparse = results_df.copy()
    threshold = pd.Series(results_df.values.flatten()).quantile(scarcity_prop)
    vsp_df_sparse[vsp_df_sparse < threshold] = 0
    vsp_np_sparse = vsp_df_sparse.values
    
    np.fill_diagonal(vsp_np_sparse, 0)
    
    if standardized:
        vsp_np_sparse = vsp_np_sparse / K
        return vsp_np_sparse
    else:
        return vsp_np_sparse

def load_dataset(dataset_dir, batch_size, seq_len, horizon, lag, scarcity_prop, train_test_split, train_valid_split):
    """
    Parameters
    ----------
    dataset_dir : file_path to the dataset
    seq_len : int. look_back window
    horizon : int. predict window
    lag: int. the lag to formulat VSP graph
    train_test_split : (train+valid)/total
    train_valid_split : train/(train+valid)

    """
    data = pd.read_csv(dataset_dir, index_col=0)
    
    total_rows = data.shape[0]
    train_valid_end_idx = int(total_rows * train_test_split) 
    train_end_idx = int(train_valid_end_idx * train_valid_split)
    data_train = data[0:train_end_idx]
    data_valid = data[train_end_idx:train_valid_end_idx]
    data_train_val = pd.concat([data_train, data_valid])
    data_test = data[train_valid_end_idx:]
    data_train_cleaned = data_train_val[~np.any(data_train_val == 0, axis=1)]
    fixed_A = compute_spillover_index(data_train_cleaned.values, horizon, lag, scarcity_prop, standardized=True)
    def create_dataset(data, start_index, end_index, seq_len, horizon):
        X, Y, EA, Ex, Ey, A = [], [], [], [], [], []
        for i in range(start_index, end_index - seq_len - horizon + 1):
            X.append(data.iloc[i:i+seq_len].values)
            Y.append(data.iloc[i+seq_len:i+seq_len+horizon].values)
            EA.append(graph_mask_generation(data.iloc[i:i+seq_len].values))
            Ex.append(data_mask_generation(data.iloc[i:i+seq_len].values))
            Ey.append(data_mask_generation(data.iloc[i+seq_len:i+seq_len+horizon].values))
            A.append(compute_spillover_index(data.iloc[i:i+seq_len].values, horizon, lag, scarcity_prop, standardized=True))
            
        return np.array(X), np.array(Y), np.array(EA), np.array(Ex), np.array(Ey), np.array(A)

    train_x, train_y, train_EA, train_Ex, train_Ey, train_A = create_dataset(data, 0, train_end_idx, seq_len, horizon)
    val_x, val_y, val_EA, val_Ex, val_Ey, val_A = create_dataset(data, train_end_idx, train_valid_end_idx, seq_len, horizon)
    train_val_x, train_val_y, train_val_EA, train_val_Ex, train_val_Ey, train_val_A = create_dataset(data, 0, train_valid_end_idx, seq_len, horizon)
    test_x, test_y, test_EA, test_Ex, test_Ey, test_A = create_dataset(data, train_valid_end_idx, total_rows, seq_len, horizon)
    
    train_loader = DataLoader(train_x, train_y, train_EA, train_Ex, train_Ey, train_A, batch_size, shuffle=True)
    val_loader = DataLoader(val_x, val_y, val_EA, val_Ex, val_Ey, val_A, batch_size, shuffle=False)
    train_val_loader = DataLoader(train_val_x, train_val_y, train_val_EA, train_val_Ex, train_val_Ey, train_val_A, batch_size, shuffle=True)
    test_loader = DataLoader(test_x, test_y, test_EA, test_Ex, test_Ey, test_A, batch_size, shuffle=False)

    return {
        'train_loader': train_loader,
        'val_loader': val_loader,
        'test_loader': test_loader,
        'train_val_loader': train_val_loader,
        'scaler': None,
        'data_train': data_train,
        'data_valid':data_valid,
        'data_test': data_test,
        'adj_mx': fixed_A
    }

def compute_mode(tensor):
    tensor_cpu = tensor.cpu()
    tensor = tensor_cpu.numpy() 
    mode_result = stats.mode(tensor, axis=0)[0]  
    return torch.tensor(mode_result)