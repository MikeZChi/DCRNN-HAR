# -*- coding: utf-8 -*-
"""
Created on Fri May 10 16:38:10 2024

@author: MC
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import os
import argparse
import numpy as np
import pandas as pd
import torch
import utils as utils
import torch.nn as nn
import time
import yaml
import sys

import warnings
warnings.filterwarnings('ignore')


os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


torch.manual_seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    
np.random.seed(42)

def mae_loss(y_pred, y_true, Ey):
    y_true_reshaped = y_true.transpose(0, 1)
    y_pred_reshaped = y_pred.transpose(0, 1)
    loss = torch.abs(y_pred_reshaped - y_true_reshaped)
    loss_filter_matrix = Ey.to(loss.device)
    loss = loss_filter_matrix * loss
    sum_loss = torch.sum(loss)
    trading_days = torch.count_nonzero(loss_filter_matrix)
    result = sum_loss / trading_days
    return result

def mse_loss(y_pred, y_true, Ey):
    y_true_reshaped = y_true.transpose(0, 1)
    y_pred_reshaped = y_pred.transpose(0, 1)
    loss = (y_pred_reshaped - y_true_reshaped)**2
    loss_filter_matrix = Ey.to(loss.device)
    loss = loss_filter_matrix * loss
    sum_loss = torch.sum(loss)
    trading_days = torch.count_nonzero(loss_filter_matrix)
    result = sum_loss / trading_days
    return result

class LayerParams:
    def __init__(self, rnn_network: torch.nn.Module, layer_type: str):
        self._rnn_network = rnn_network 
        self._params_dict = {}
        self._biases_dict = {}
        self._type = layer_type

    def get_weights(self, shape): 
        if shape not in self._params_dict:
            nn_param = torch.nn.Parameter(torch.empty(*shape, device=device))
            torch.nn.init.xavier_normal_(nn_param)
            self._params_dict[shape] = nn_param
            self._rnn_network.register_parameter('{}_weight_{}'.format(self._type, str(shape)), nn_param)
        return self._params_dict[shape]

    def get_biases(self, length, bias_start=0.0): 
        if length not in self._biases_dict:
            biases = torch.nn.Parameter(torch.empty(length, device=device))
            torch.nn.init.constant_(biases, bias_start) 
            self._biases_dict[length] = biases
            self._rnn_network.register_parameter('{}_biases_{}'.format(self._type, str(length)), biases)

        return self._biases_dict[length]


class DCGRUCell(torch.nn.Module):
    def __init__(self, num_units, adjacency_list, filter_matrix, adj_mx, rolling_window, max_diffusion_step, num_nodes, nonlinearity='relu',
                 filter_type="laplacian", use_gc_for_ru=True):
        """
        :param num_units:
        :param adjacency_list:
        :param adj_mx:
        :param rolling_window: bool
        :param max_diffusion_step: k
        :param num_nodes:
        :param nonlinearity:
        :param filter_type: "laplacian", "random_walk", "dual_random_walk".
        :param use_gc_for_ru: whether to use Graph convolution to calculate the reset and update gates.
        """

        super().__init__() 
        self._activation = torch.relu if nonlinearity == 'relu' else torch.tanh
        self._num_nodes = num_nodes
        self._num_units = num_units
        self._max_diffusion_step = max_diffusion_step
        self.rolling_window = rolling_window
        self._supports = []
        self._use_gc_for_ru = use_gc_for_ru
        if self.rolling_window == False:
            supports = []
            adj_mx_expanded = torch.tensor(adj_mx, dtype=torch.float32).unsqueeze(0)
            adj_mx_expanded = adj_mx_expanded.to(filter_matrix.device)
            filtered_adj_mx = filter_matrix * adj_mx_expanded 
            filtered_adj_mx_list = [filtered_adj_mx[i] for i in range(filtered_adj_mx.size(0))]
            
            if filter_type == "laplacian":
                supports = [utils.calculate_scaled_laplacian(mx.cpu().numpy().astype('float32'), lambda_max=None) for mx in filtered_adj_mx_list]
            elif filter_type == "random_walk":
                supports = [utils.calculate_random_walk_matrix(mx.cpu().numpy().astype('float32')) for mx in filtered_adj_mx_list]
            else:
                supports = [utils.calculate_scaled_laplacian(mx.cpu().numpy().astype('float32'), lambda_max=None) for mx in filtered_adj_mx_list]
            
            
            self._supports = supports
                
            self._fc_params = LayerParams(self, 'fc')

            self._gconv_params = LayerParams(self, 'gconv')
        
        elif self.rolling_window == True:
            supports = []
            adj_mx_expanded = adjacency_list
            adj_mx_expanded = adj_mx_expanded.to(device)
            filter_matrix = filter_matrix.to(device)
            filtered_adj_mx = filter_matrix * adj_mx_expanded 
            filtered_adj_mx_list = [filtered_adj_mx[i] for i in range(filtered_adj_mx.size(0))]
            if filter_type == "laplacian":
                supports = [utils.calculate_scaled_laplacian(mx.cpu().numpy().astype('float32'), lambda_max=None) for mx in filtered_adj_mx_list]
            elif filter_type == "random_walk":
                supports = [utils.calculate_random_walk_matrix(mx.cpu().numpy().astype('float32')) for mx in filtered_adj_mx_list]
            else:
                supports = [utils.calculate_scaled_laplacian(mx.cpu().numpy().astype('float32'), lambda_max=None) for mx in filtered_adj_mx_list]
                 
            self._supports = supports
            
                
            self._fc_params = LayerParams(self, 'fc')

            self._gconv_params = LayerParams(self, 'gconv')
        
        else:
            raise ValueError("Wrong argument for rolling_window")
            sys.exit(1)

    @staticmethod
    def _build_sparse_matrix(L):
        L = L.tocoo()
        indices = np.column_stack((L.row, L.col))
        indices = indices[np.lexsort((indices[:, 0], indices[:, 1]))]
        L = torch.sparse_coo_tensor(indices.T, L.data, L.shape, device=device)
        return L
    
    def _fc(self, inputs, state, output_size, bias_start=0.0):
        batch_size = inputs.shape[0]
        inputs = torch.reshape(inputs, (batch_size * self._num_nodes, -1))
            
        state = torch.reshape(state, (batch_size * self._num_nodes, -1))
            
        inputs_and_state = torch.cat([inputs, state], dim=-1)
        input_size = inputs_and_state.shape[-1] 
        weights = self._fc_params.get_weights((input_size, output_size))
        value = torch.matmul(inputs_and_state, weights)
        biases = self._fc_params.get_biases(output_size, bias_start)
        value += biases
        bn = nn.BatchNorm1d(value.shape[-1]).to(value.device)
        value = bn(value)
        return value 
    
    @staticmethod
    def _concat(x, x_):
        x_ = x_.unsqueeze(0)
        return torch.cat([x, x_], dim=0)
    
    def _gconv(self, inputs, state, output_size, bias_start=0.0):
        batch_size = inputs.shape[0]
        inputs = torch.reshape(inputs, (batch_size, self._num_nodes, -1))
        state = torch.reshape(state, (batch_size, self._num_nodes, -1))
        inputs_and_state = torch.cat([inputs, state], dim=2)
        input_size = inputs_and_state.size(2)
        x = inputs_and_state
        x0_reshape = x
        if self._max_diffusion_step == 0:
            pass
        else:
            x_list = []
            if self.rolling_window == True:
                supports = torch.stack([torch.tensor(s, dtype=torch.float32) for s in self._supports]).to(x.device)
                x1_reshape = torch.bmm(supports, x0_reshape)
                x0_reshape_copy = x0_reshape.permute(1, 2, 0)
                x0_reshape_copy = x0_reshape_copy.reshape(x0_reshape_copy.shape[0], -1)
                x1_reshape_copy = x1_reshape.permute(1, 2, 0)
                x1_reshape_copy = x1_reshape_copy.reshape(x1_reshape_copy.shape[0], -1)
                    
                x_list = [x0_reshape_copy.unsqueeze(0), x1_reshape_copy.unsqueeze(0)]
    
                for k in range(2, self._max_diffusion_step + 1):
                    x2_reshape = 2 * torch.bmm(supports, x1_reshape) - x0_reshape
                    x2_reshape_copy = x2_reshape.permute(1, 2, 0)
                    x2_reshape_copy = x2_reshape_copy.reshape(x2_reshape_copy.shape[0], -1)
                    x_list.append(x2_reshape_copy.unsqueeze(0))
                    x1_reshape, x0_reshape = x2_reshape, x1_reshape
                x = torch.cat(x_list, dim=0)
                
            else:
                supports = torch.stack([torch.tensor(s, dtype=torch.float32) for s in self._supports]).to(x.device)
                    
                x1_reshape = torch.bmm(supports, x0_reshape)  
                    
                x0_reshape_copy = x0_reshape.permute(1, 2, 0)
                x0_reshape_copy = x0_reshape_copy.reshape(x0_reshape_copy.shape[0], -1)
                x1_reshape_copy = x1_reshape.permute(1, 2, 0)
                x1_reshape_copy = x1_reshape_copy.reshape(x1_reshape_copy.shape[0], -1)
                x_list = [x0_reshape_copy.unsqueeze(0), x1_reshape_copy.unsqueeze(0)]
    
                for k in range(2, self._max_diffusion_step + 1):
                    x2_reshape = 2 * torch.bmm(supports, x1_reshape) - x0_reshape
                    x2_reshape_copy = x2_reshape.permute(1, 2, 0)
                    x2_reshape_copy = x2_reshape_copy.reshape(x2_reshape_copy.shape[0], -1)
                    x_list.append(x2_reshape_copy.unsqueeze(0))
                    x1_reshape, x0_reshape = x2_reshape, x1_reshape
                x = torch.cat(x_list, dim=0)
        num_matrices = self._max_diffusion_step + 1 
        x = torch.reshape(x, shape=[num_matrices, self._num_nodes, input_size, batch_size])
        x = x.permute(3, 1, 2, 0)
        x = torch.reshape(x, shape=[batch_size * self._num_nodes, input_size * num_matrices])
        weights = self._gconv_params.get_weights((input_size * num_matrices, output_size))
        x = torch.matmul(x, weights)
        biases = self._gconv_params.get_biases(output_size, bias_start)

        x += biases
        bn = nn.BatchNorm1d(x.shape[-1]).to(x.device)
        x = bn(x)
        return torch.reshape(x, [batch_size, self._num_nodes * output_size])

    def forward(self, inputs, hx):
        """Gated recurrent unit (GRU) with Graph Convolution.
        :param inputs (x): (batch size, num_nodes * input_dim)
        :param hx (hidden states): (batch size, num_nodes * num_units) (num_units = rnn_units)

        :return
        - Output: A `2-D` tensor with shape `(batch size, num_nodes * 2 * num_units)`.
        """
        output_size = 2 * self._num_units
        if self._use_gc_for_ru:
            fn = self._gconv
        else:
            fn = self._fc
        value = fn(inputs, hx, output_size, bias_start=0.0001)
        value = torch.reshape(value, (-1, self._num_nodes, output_size))
        r, u = torch.split(tensor=value, split_size_or_sections=self._num_units, dim=-1)
        r = torch.sigmoid(r)
        u = torch.sigmoid(u)
        
        r = torch.reshape(r, (-1, self._num_nodes * self._num_units))
        u = torch.reshape(u, (-1, self._num_nodes * self._num_units))
        c = self._gconv(inputs, r * hx, self._num_units)
        if self._activation is not None:
            c = self._activation(c)
        
        new_state = u * hx + (1.0 - u) * c 
        return new_state

class Seq2SeqAttrs:
    def __init__(self, adj_mx, **model_kwargs):
        self.adj_mx = adj_mx
        self.max_diffusion_step = int(model_kwargs.get('max_diffusion_step', 2))
        self.rolling_window = bool(model_kwargs.get('rolling_window', False))
        self.filter_type = model_kwargs.get('filter_type', 'laplacian')
        self.num_nodes = int(model_kwargs.get('num_nodes', 1))
        self.num_rnn_layers = int(model_kwargs.get('num_rnn_layers', 1))
        self.rnn_units = int(model_kwargs.get('rnn_units'))
        self.hidden_state_size = self.num_nodes * self.rnn_units


class EncoderModel(nn.Module, Seq2SeqAttrs):
    def __init__(self, adj_mx, **model_kwargs):
        nn.Module.__init__(self) 
        Seq2SeqAttrs.__init__(self, adj_mx, **model_kwargs)
        self.input_dim = int(model_kwargs.get('input_dim', 1))
        self.seq_len = int(model_kwargs.get('seq_len'))
        self.adj_mx = adj_mx
        self.dcgru_layers = None

    def forward(self, inputs, adjacency_list, filter_matrix, hidden_state=None):
        """
        Encoder forward pass.

        :param inputs: shape (batch_size, self.num_nodes * self.input_dim)
        :param hidden_state: (num_layers, batch_size, self.hidden_state_size)
               optional, zeros if not provided
        :return: output: # shape (batch_size, self.hidden_state_size)
                 hidden_state # shape (num_layers, batch_size, self.hidden_state_size)
                 (lower indices mean lower layers)
        """
        if self.dcgru_layers is None:
            self.dcgru_layers = nn.ModuleList(
                [DCGRUCell(self.rnn_units, adjacency_list, filter_matrix, self.adj_mx, self.rolling_window, self.max_diffusion_step, self.num_nodes,
                           filter_type=self.filter_type) for _ in range(self.num_rnn_layers)])
        
        batch_size, _ = inputs.size() 
        if hidden_state is None:
            hidden_state = torch.zeros((self.num_rnn_layers, batch_size, self.hidden_state_size), device=device)
        hidden_states = []
        output = inputs
        for layer_num, dcgru_layer in enumerate(self.dcgru_layers):
            next_hidden_state = dcgru_layer(output, hidden_state[layer_num])
            hidden_states.append(next_hidden_state)
            output = next_hidden_state
        return output, torch.stack(hidden_states)
        
class DecoderModel(nn.Module, Seq2SeqAttrs):
    def __init__(self, adj_mx, **model_kwargs):
        nn.Module.__init__(self)
        Seq2SeqAttrs.__init__(self, adj_mx, **model_kwargs)
        self.output_dim = int(model_kwargs.get('output_dim', 1))
        self.horizon = int(model_kwargs.get('horizon', 1))
        self.projection_layer = nn.Linear(self.rnn_units, self.output_dim)
        self.adj_mx = adj_mx
        self.dcgru_layers = None

    def forward(self, inputs, adjacency_list, hidden_state=None):
        """
        Decoder forward pass.

        :param inputs: shape (batch_size, self.num_nodes * self.output_dim)
        :param hidden_state: (num_layers, batch_size, self.hidden_state_size)
               optional, zeros if not provided
        :return: output: # shape (batch_size, self.num_nodes * self.output_dim)
                 hidden_state # shape (num_layers, batch_size, self.hidden_state_size)
                 (lower indices mean lower layers)
        """
        filter_matrix = torch.ones((inputs.size()[0], inputs.size()[1], inputs.size()[1]), dtype=torch.float32)
        if self.dcgru_layers is None:
            self.dcgru_layers = nn.ModuleList(
               [DCGRUCell(self.rnn_units, adjacency_list, filter_matrix, self.adj_mx, self.rolling_window, self.max_diffusion_step,
                          self.num_nodes, filter_type=self.filter_type) for _ in range(self.num_rnn_layers)])
        inputs = inputs.to(dtype=torch.float32)
        if hidden_state is not None:
            hidden_state = [hs.to(dtype=torch.float32) for hs in hidden_state]
        hidden_states = []
        output = inputs
        for layer_num, dcgru_layer in enumerate(self.dcgru_layers):
            next_hidden_state = dcgru_layer(output, hidden_state[layer_num])
            hidden_states.append(next_hidden_state)
            output = next_hidden_state
        
        output = output.to(dtype=torch.float32)
        projected = self.projection_layer(output.view(-1, self.rnn_units))
        output = projected.view(-1, self.num_nodes * self.output_dim)

        return output, torch.stack(hidden_states)

class HARModel(nn.Module):
    def __init__(self):
        super(HARModel, self).__init__()
        self.linear = nn.Linear(3, 1)

    def forward(self, daily, weekly, monthly):
        features = torch.stack([daily, weekly, monthly], dim=-1)
        batch_size, num_node, _ = features.shape
        features = features.view(-1, 3)
        out = self.linear(features)
        return out.view(batch_size, num_node)
    
    
class DCRNNModel(nn.Module, Seq2SeqAttrs): 
    def __init__(self, adj_mx, **model_kwargs):
        super().__init__()
        Seq2SeqAttrs.__init__(self, adj_mx, **model_kwargs)
        self.encoder_model = EncoderModel(adj_mx, **model_kwargs)
        self.decoder_model = DecoderModel(adj_mx, **model_kwargs)
        self.HAR_model = HARModel()
        self.use_curriculum_learning = bool(model_kwargs.get('use_curriculum_learning', False))

    def encoder(self, inputs, adjacency_list, filter_matrix):
        """
        encoder forward pass on t time steps
        :param inputs: shape (seq_len, batch_size, num_sensor * input_dim)
        :return: encoder_hidden_state: (num_layers, batch_size, self.hidden_state_size)
        """
        HAR_input_list = []
        encoder_hidden_state = None
        filter_matrix_reshape = filter_matrix.transpose(0, 1)
        for t in range(self.encoder_model.seq_len):
            _, encoder_hidden_state = self.encoder_model(inputs[t], adjacency_list, filter_matrix_reshape[t], encoder_hidden_state) 
            if self.encoder_model.seq_len - t <= 22:
                HAR_input_list.append(inputs[t])
                

        HAR_input = torch.stack(HAR_input_list, dim=-1) 
        daily_vol   = HAR_input[..., -1]                
        weekly_vol  = torch.mean(HAR_input[..., -5:-1], dim=-1) 
        monthly_vol = torch.mean(HAR_input[..., : -5], dim=-1)

        HAR_output = self.HAR_model(daily_vol, weekly_vol, monthly_vol)
        
        return encoder_hidden_state, HAR_output

    def decoder(self, encoder_hidden_state, HAR_output, adjacency_list):
        """
        Decoder forward pass
        :param encoder_hidden_state: (num_layers, batch_size, self.hidden_state_size)
        :param labels: (self.horizon, batch_size, self.num_nodes * self.output_dim) [optional, not exist for inference]
        :param batches_seen: global step [optional, not exist for inference]
        :return: output: (self.horizon, batch_size, self.num_nodes * self.output_dim)
        """
        batch_size = encoder_hidden_state.size(1)
        go_symbol = torch.zeros((batch_size, self.num_nodes * self.decoder_model.output_dim), device=device)
        decoder_hidden_state = encoder_hidden_state
        decoder_input = go_symbol 

        outputs = []

        for t in range(self.decoder_model.horizon):
            decoder_output, decoder_hidden_state = self.decoder_model(decoder_input, adjacency_list, decoder_hidden_state)
            decoder_output = decoder_output + HAR_output
            decoder_input = decoder_output 
            outputs.append(decoder_output) 
        outputs = torch.stack(outputs)
        
        return outputs

    def forward(self, inputs, adjacency_list, filter_matrix): 
        """
        seq2seq forward pass
        :param inputs: shape (seq_len, batch_size, num_sensor * input_dim)
        :param labels: shape (horizon, batch_size, num_sensor * output) optional
        :param batches_seen: batches seen till now
        :return: output: (self.horizon, batch_size, self.num_nodes * self.output_dim)
        """
        encoder_hidden_state, HAR_output  = self.encoder(inputs, adjacency_list, filter_matrix)
        outputs = self.decoder(encoder_hidden_state, HAR_output, adjacency_list) 

        return outputs
    
    
    
class DCRNNSupervisor:
    def __init__(self, **kwargs):
        self._kwargs = kwargs
        self._data_kwargs = kwargs.get('data')
        self._model_kwargs = kwargs.get('model')
        self._train_kwargs = kwargs.get('train')
        self.max_grad_norm = self._train_kwargs.get('max_grad_norm', 1.)
        self.batch_size = self._data_kwargs['batch_size']
        self.rolling_window = self._model_kwargs['rolling_window']

        self.num_nodes = int(self._model_kwargs.get('num_nodes', 1))
        self.input_dim = int(self._model_kwargs.get('input_dim', 1))
        self.seq_len = int(self._model_kwargs.get('seq_len'))  
        self.output_dim = int(self._model_kwargs.get('output_dim', 1))
        self.use_curriculum_learning = bool(self._model_kwargs.get('use_curriculum_learning', False))
        self.horizon = int(self._model_kwargs.get('horizon', 1))  
        self.lag = int(self._model_kwargs.get('lag', 4))
        self.scarcity_prop = float(self._model_kwargs.get('scarcity_prop', 0.1))
        self._data = utils.load_dataset(self._data_kwargs.get('dataset_dir'), self._data_kwargs.get('batch_size'), self.seq_len, 
                                        self.horizon, self.lag, self.scarcity_prop, self._data_kwargs.get('train_test_split'), self._data_kwargs.get('train_val_split'))
        self.standard_scaler = self._data['scaler']
        self.adj_mx = self._data['adj_mx']

        dcrnn_model = DCRNNModel(self.adj_mx, **self._model_kwargs)
        self.dcrnn_model = dcrnn_model.cuda() if torch.cuda.is_available() else dcrnn_model
        print("Model created")
    
    def save_model(self, epoch):
        if not os.path.exists('models_mc/'):
            os.makedirs('models_mc/')

        config = dict(self._kwargs)
        config['model_state_dict'] = self.dcrnn_model.state_dict()
        config['epoch'] = epoch
        torch.save(config, 'models_mc/epo%d.tar' % epoch)
        print("Saved model at epoch {}".format(epoch+1))
        return 'models_mc/epo%d.tar' % epoch

    def load_model(self, epoch_num):
        self._setup_graph()
        assert os.path.exists('models_mc/epo%d.tar' % epoch_num), 'Weights at epoch %d not found' % epoch_num
        checkpoint = torch.load('models_mc/epo%d.tar' % epoch_num, map_location='cpu')
        self.dcrnn_model.load_state_dict(checkpoint['model_state_dict'])
        print("Loaded model at epoch {}".format(epoch_num+1))
        print("Started iterated h-step ahead forecast.")
        self.iterated_h_step_ahead_forecast()
        print("Finished iterated h-step ahead forecast.")

    def _setup_graph(self):
        with torch.no_grad():
            self.dcrnn_model = self.dcrnn_model.eval()
            
    def append_last_rows(x):
        fixed_part = x[0:1, :, :]
        fixed_part = fixed_part.squeeze(0)
        last_rows = x[1:, -1:, :]
        last_rows = last_rows.squeeze(1)
        result = torch.cat([fixed_part, last_rows], dim=0)
    
        return result
    
    def iterated_h_step_ahead_forecast(self, dataset='test'): 
        column_names = self._data['data_test'].columns.tolist()
        self.dcrnn_model = self.dcrnn_model.eval()
        with torch.no_grad():
            val_iterator = self._data['{}_loader'.format(dataset)].get_iterator()
            if self.horizon > 1:
                y_pred_list = []
                y_true_list = []
                for i, (x, y, EA, Ex, Ey, A) in enumerate(val_iterator):
                    x, y, EA, Ex, Ey, A = self._prepare_data(x, y, EA, Ex, Ey, A)
                    output = self.dcrnn_model(x, A, EA)
                    output = output.transpose(0, 1)
                    y = y.transpose(0, 1)
                    output_temp0 = output[0,:,:].squeeze(0) 
                    y_temp0 = y[0,:,:].squeeze(0)
                    for j in range(output.shape[0]-1):
                        output_temp1 = output[j+1,:,:].squeeze(0)
                        y_temp1 = y[j+1,:,:].squeeze(0)
                        avg_update = (output_temp0[-(self.horizon-1):] + output_temp1[:(self.horizon-1)]) / 2
                        output_temp0[-(self.horizon-1):] = avg_update
                        output_temp0 = torch.cat([output_temp0, output_temp1[-1].unsqueeze(0)], dim=0)
                        y_temp0 = torch.cat([y_temp0, y_temp1[-1].unsqueeze(0)], dim=0)
                    y_pred_list.append(output_temp0.cpu().numpy())
                    y_true_list.append(y_temp0.cpu().numpy()) 
            else:
                y_pred_list = []
                y_true_list = []
                for i, (x, y, EA, Ex, Ey, A) in enumerate(val_iterator):
                    x, y, EA, Ex, Ey, A = self._prepare_data(x, y, EA, Ex, Ey, A)
                    output = self.dcrnn_model(x, A, EA)
                    output = output.transpose(0, 1)
                    y = y.transpose(0, 1) 
                    output = output.squeeze(1)
                    y = y.squeeze(1)
                    y_pred_list.append(output.cpu().numpy())
                    y_true_list.append(y.cpu().numpy())
                    
            y_pred_concatenated = np.concatenate(y_pred_list, axis=0)
            y_true_concatenated = np.concatenate(y_true_list, axis=0)
            rv_hat = pd.DataFrame(data = y_pred_concatenated, columns = column_names)
            rv_true = pd.DataFrame(data = y_true_concatenated, columns = column_names)
            df = pd.DataFrame()
            for market_index in column_names:
                pred_column = market_index+'_forecast'
                true_column = market_index+'_true'
                df[pred_column] = rv_hat[market_index]
                df[true_column] = rv_true[market_index]
                df.loc[df[true_column]==0,pred_column] = 0.
            if not os.path.exists('models_mc/'):
                os.makedirs('models_mc/')
            
            filename = 'HAR_DCRNN_result'
            
            file_path = r'models_mc/{}.csv'.format(filename)
            df.to_csv(file_path, index=False)
            

    def train(self, **kwargs):
        kwargs.update(self._train_kwargs)
        return self._train(**kwargs)

    def evaluate(self, dataset='test'):
        """
        Computes mean L1Loss
        :return: mean L1Loss
        """
        with torch.no_grad():
            self.dcrnn_model = self.dcrnn_model.eval()

            val_iterator = self._data['{}_loader'.format(dataset)].get_iterator()
            losses = []

            y_truths = []
            y_preds = []

            for _, (x, y, EA, Ex, Ey, A) in enumerate(val_iterator):
                x, y, EA, Ex, Ey, A = self._prepare_data(x, y, EA, Ex, Ey, A)

                    
                output = self.dcrnn_model(x, A, EA)
                loss = self._compute_loss(y, output, Ey)
                losses.append(loss.item())

                y_truths.append(y.cpu())
                y_preds.append(output.cpu())

            mean_loss = np.mean(losses)

            y_preds = np.concatenate(y_preds, axis=1)
            y_truths = np.concatenate(y_truths, axis=1)

            return mean_loss, {'prediction': y_preds, 'truth': y_truths}

    def _train(self, base_lr, steps, patience, epochs, lr_decay_ratio, test_every_n_epochs,epsilon, **kwargs):
        best_epoch_num = 0
        min_val_loss = float('inf')
        wait = 0
        
        optimizer = torch.optim.Adam(self.dcrnn_model.parameters(), lr=base_lr, eps=epsilon)
        
        lr_scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=steps, gamma=lr_decay_ratio)
        
        print('Start training ...')

        num_batches = self._data['train_val_loader'].num_batch

        for epoch_num in range(0, epochs):

            self.dcrnn_model = self.dcrnn_model.train()

            train_iterator = self._data['train_val_loader'].get_iterator()
            
            batches_seen = num_batches * epoch_num
            
            losses = []

            start_time = time.time()

            for _, (x, y, EA, Ex, Ey, A) in enumerate(train_iterator):
                optimizer.zero_grad()

                x, y, EA, Ex, Ey, A = self._prepare_data(x, y, EA, Ex, Ey, A)
                output = self.dcrnn_model(x, A, EA)
                
                if batches_seen == 0:
                    p_count = sum(p.numel() for p in self.dcrnn_model.parameters() if p.requires_grad)
                    print(f'Number of parameters in dcrnn_model: {p_count}')
                    optimizer = torch.optim.Adam(self.dcrnn_model.parameters(), lr=base_lr, eps=epsilon)


                loss = self._compute_loss(y, output, Ey)

                losses.append(loss.item())
                batches_seen += 1
                loss.backward()
                
                torch.nn.utils.clip_grad_norm_(self.dcrnn_model.parameters(), self.max_grad_norm)
                
                optimizer.step()
                
                
                
            print("epoch complete ...")
            lr_scheduler.step()
            print("evaluating now ...")

            val_loss, _ = self.evaluate(dataset='test')

            end_time = time.time()

            print('Epoch [{}/{}] train_mae: {:.10f}, val_mae: {:.10f}, lr: {:.6f}, ' \
                          '{:.1f}s'.format(epoch_num+1, epochs,
                                           np.mean(losses), val_loss, lr_scheduler.get_lr()[0],
                                           (end_time - start_time)))

            if val_loss < min_val_loss:
                min_val_loss = val_loss
                wait = 0
                self.save_model(epoch_num)
                best_epoch_num = epoch_num
                print('Best validation loss: %.10f' % val_loss)

            elif val_loss >= min_val_loss:
                wait += 1
                if wait == patience:
                    early_stop_epoch_num = epoch_num + 1
                    print('Early stopping at epoch: %d' % early_stop_epoch_num)
                    print('Early stopping with: %.10f' % min_val_loss)
                    break
        
        self.load_model(best_epoch_num)

    def _prepare_data(self, x, y, EA, Ex, Ey, A):
        x, y, EA, Ex, Ey, A = self._get_x_y(x, y, EA, Ex, Ey, A)
        x, y = self._get_x_y_in_correct_dims(x, y)
        return x.to(device), y.to(device), EA.to(device), Ex.to(device), Ey.to(device), A.to(device)

    def _get_x_y(self, x, y, EA, Ex, Ey, A):
        """
        :param x: shape (batch_size, seq_len, num_sensor, input_dim)
        :param y: shape (batch_size, horizon, num_sensor, input_dim)
        :returns x shape (seq_len, batch_size, num_sensor, input_dim)
                 y shape (horizon, batch_size, num_sensor, input_dim)
        """
        x = torch.from_numpy(x).float()
        y = torch.from_numpy(y).float()
        EA = torch.from_numpy(EA).float()
        Ex = torch.from_numpy(Ex).float()
        Ey = torch.from_numpy(Ey).float()
        A = torch.from_numpy(A).float()
        if x.dim() == 3:
             x = x.unsqueeze(-1)  
        if y.dim() == 3:
             y = y.unsqueeze(-1)
        x = x.permute(1, 0, 2, 3)
        y = y.permute(1, 0, 2, 3)
        return x, y, EA, Ex, Ey, A

    def _get_x_y_in_correct_dims(self, x, y):
        """
        :param x: shape (seq_len, batch_size, num_sensor, input_dim)
        :param y: shape (horizon, batch_size, num_sensor, input_dim)
        :return: x: shape (seq_len, batch_size, num_sensor * input_dim)
                 y: shape (horizon, batch_size, num_sensor * output_dim)
        """
        batch_size = x.size(1)
        x = x.view(self.seq_len, batch_size, self.num_nodes * self.input_dim)
        y = y[..., :self.output_dim].view(self.horizon, batch_size,
                                          self.num_nodes * self.output_dim)
        return x, y
    
    def _compute_loss(self, y_true, y_predicted, Ey):
        return mae_loss(y_predicted, y_true, Ey)


   
def main(args):
    with open(args.config_filename) as f:
        supervisor_config = yaml.load(f, Loader=yaml.SafeLoader)
        supervisor = DCRNNSupervisor(**supervisor_config) 
        supervisor.train()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config_filename', default='data/model/dcrnn_har_config.yaml', type=str,
                        help='Configuration filename for restoring the model.')
    parser.add_argument('--use_cpu_only', default=False, type=bool, help='Set to true to only use cpu.')
    args = parser.parse_args()
    main(args)
    
    
    
